<?php
// sub.php - subscription endpoint
require_once __DIR__ . '/includes/functions.php';
ensure_bootstrap_data();

$settings = load_json('settings.json', ["subscription_token" => ""]);
$token_required = trim($settings['subscription_token'] ?? '');

if ($token_required !== '') {
  $token = $_GET['token'] ?? '';
  if (!hash_equals($token_required, (string)$token)) {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    echo "403 Forbidden";
    exit;
  }
}

$servers = load_json('servers.json', []);
$lines = [];
foreach ($servers as $s) {
  $uri = trim($s['uri'] ?? '');
  if ($uri !== '') $lines[] = $uri;
}
$payload = implode("\n", $lines) . "\n";

header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

if (isset($_GET['raw']) && $_GET['raw'] == '1') {
  echo $payload;
} else {
  echo base64_encode($payload);
}
exit;
