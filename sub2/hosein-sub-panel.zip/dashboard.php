<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
ensure_bootstrap_data();
require_login();

$servers = load_json('servers.json', []);
$settings = load_json('settings.json', ["subscription_token" => "", "title" => "Subscription Panel"]);
$sub_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']);
$sub_url = rtrim($sub_url, '/\\') . '/sub.php';
if (!empty($settings['subscription_token'])) {
  $sub_url .= '?token=' . urlencode($settings['subscription_token']);
}

include __DIR__ . '/layout_header.php';
?>
<div class="row g-3">
  <div class="col-lg-7">
    <div class="card p-3">
      <div class="d-flex align-items-center justify-content-between">
        <h5 class="mb-0">لیست سرورها</h5>
        <span class="badge badge-soft"><?php echo count($servers); ?> مورد</span>
      </div>
      <div class="mt-3">
        <?php if (!count($servers)): ?>
          <div class="muted">هنوز سروری اضافه نشده.</div>
        <?php else: ?>
          <div class="table-responsive">
            <table class="table table-dark table-sm align-middle mb-0">
              <thead>
                <tr>
                  <th>نام</th>
                  <th>لینک</th>
                  <th class="text-end">عملیات</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($servers as $s): ?>
                  <tr>
                    <td><?php echo h($s['name'] ?? '-'); ?></td>
                    <td class="mono" style="max-width:420px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                      <?php echo h($s['uri'] ?? ''); ?>
                    </td>
                    <td class="text-end">
                      <a class="btn btn-outline-light btn-sm" href="edit.php?id=<?php echo urlencode($s['id']); ?>">ویرایش</a>
                      <a class="btn btn-outline-danger btn-sm" href="delete.php?id=<?php echo urlencode($s['id']); ?>" onclick="return confirm('حذف شود؟')">حذف</a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="card p-3 mb-3">
      <h5 class="mb-2">لینک سابسکریپشن</h5>
      <div class="muted mb-2">این لینک را داخل V2rayNG / V2Box / Hiddify وارد کن.</div>
      <div class="input-group">
        <input class="form-control mono" id="subUrl" value="<?php echo h($sub_url); ?>" readonly>
        <button class="btn btn-light" type="button" onclick="navigator.clipboard.writeText(document.getElementById('subUrl').value)">کپی</button>
      </div>
      <div class="muted mt-2">برای تست خام: <span class="mono"><?php echo h($sub_url . (strpos($sub_url,'?')!==false?'&':'?') . 'raw=1'); ?></span></div>
    </div>

    <div class="card p-3">
      <h5 class="mb-3">افزودن سرور جدید</h5>
      <form method="post" action="save.php">
        <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>">
        <div class="mb-2">
          <label class="form-label">نام نمایشی</label>
          <input class="form-control" name="name" placeholder="مثلاً Finland | VPN" required>
        </div>
        <div class="mb-2">
          <label class="form-label">لینک کانفیگ (هر پروتکلی: vless/vmess/trojan/ss/...)</label>
          <textarea class="form-control mono" name="uri" rows="4" placeholder="vless://..." required></textarea>
          <div class="muted mt-1">هر سرور = یک لینک در یک خط.</div>
        </div>
        <button class="btn btn-light w-100" type="submit">ثبت</button>
      </form>
    </div>
  </div>
</div>

<div class="card p-3 mt-3">
  <h6 class="mb-2">نکته</h6>
  <div class="muted">
    این پنل خروجی Subscription را به صورت Base64 از لیست لینک‌ها تولید می‌کند (مناسب V2Ray/Xray کلاینت‌ها).
    تبدیل به فرمت‌های دیگر مثل Clash/Sing-box/YAML نیاز به سرویس «converter» جدا دارد.
  </div>
</div>

<?php include __DIR__ . '/layout_footer.php'; ?>
