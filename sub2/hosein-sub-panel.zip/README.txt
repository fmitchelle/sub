راهنمای نصب سریع (cPanel)
1) فایل zip را Extract کن داخل public_html (یا یک ساب‌فولدر مثل /subpanel).
2) مسیر data/ و فایل‌های داخلش باید قابل نوشتن باشند:
   - پوشه data : 755 یا 775
   - فایل‌های json : 644
3) آدرس پنل:
   /login.php
   یوزر/پسورد پیش‌فرض: hosein / hosein
   (بعد از اولین ورود از Settings رمز را عوض کن)
4) آدرس خروجی سابسکریپشن:
   /sub.php
   اگر در Settings توکن گذاشتی:
   /sub.php?token=YOURTOKEN
5) افزودن سرور: داخل Dashboard → Add
هر خط یک لینک (vless/vmess/trojan/ss/...) پشتیبانی می‌شود.

نکته: این پروژه لینک‌ها را به Base64 Subscription تبدیل می‌کند (V2Ray/Xray clients).
برای تبدیل به Clash/Sing-box/YAML باید converter جداگانه استفاده شود.
