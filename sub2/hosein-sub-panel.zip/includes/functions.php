<?php
// includes/functions.php
function data_path(string $file): string {
  return __DIR__ . '/../data/' . $file;
}

function load_json(string $file, $default) {
  $p = data_path($file);
  if (!file_exists($p)) return $default;
  $raw = file_get_contents($p);
  $j = json_decode($raw, true);
  return is_array($j) ? $j : $default;
}

function save_json(string $file, $data): void {
  $p = data_path($file);
  $dir = dirname($p);
  if (!is_dir($dir)) mkdir($dir, 0755, true);
  $tmp = $p . '.tmp';
  file_put_contents($tmp, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
  rename($tmp, $p);
}

function h($s): string {
  return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function now_iso(): string {
  return gmdate('c');
}

function ensure_bootstrap_data(): void {
  // settings.json
  $settings = load_json('settings.json', []);
  if (!$settings) {
    $settings = [
      "subscription_token" => "",
      "title" => "Hosein Subscription",
      "updated_at" => now_iso()
    ];
    save_json('settings.json', $settings);
  }

  // servers.json
  $servers = load_json('servers.json', []);
  if (!is_array($servers)) {
    $servers = [];
    save_json('servers.json', $servers);
  }

  // users.json
  $users = load_json('users.json', []);
  if (!$users) {
    // default user: hosein / hosein  (CHANGE IT after first login)
    $users = [
      [
        "username" => "hosein",
        "password_hash" => password_hash("hosein", PASSWORD_DEFAULT),
        "created_at" => now_iso()
      ]
    ];
    save_json('users.json', $users);
  }
}
