<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
ensure_bootstrap_data();

if (is_logged_in()) {
  header('Location: dashboard.php');
  exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = trim($_POST['username'] ?? '');
  $password = (string)($_POST['password'] ?? '');

  $users = load_json('users.json', []);
  $found = null;
  foreach ($users as $u) {
    if (isset($u['username']) && hash_equals($u['username'], $username)) {
      $found = $u;
      break;
    }
  }

  if ($found && isset($found['password_hash']) && password_verify($password, $found['password_hash'])) {
    session_regenerate_id(true);
    $_SESSION['user'] = $username;
    header('Location: dashboard.php');
    exit;
  } else {
    $error = 'نام کاربری یا رمز عبور اشتباه است.';
  }
}

include __DIR__ . '/layout_header.php';
?>
<div class="row justify-content-center">
  <div class="col-md-6 col-lg-5">
    <div class="card p-4">
      <h5 class="mb-3">ورود</h5>
      <p class="muted mb-4">پیش‌فرض: <span class="badge badge-soft">hosein</span> / <span class="badge badge-soft">hosein</span> (بعد از ورود حتماً عوضش کن)</p>
      <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo h($error); ?></div>
      <?php endif; ?>
      <form method="post">
        <div class="mb-3">
          <label class="form-label">نام کاربری</label>
          <input class="form-control" name="username" autocomplete="username" required>
        </div>
        <div class="mb-3">
          <label class="form-label">رمز عبور</label>
          <input class="form-control" type="password" name="password" autocomplete="current-password" required>
        </div>
        <button class="btn btn-light w-100" type="submit">ورود</button>
      </form>
    </div>
  </div>
</div>
<?php include __DIR__ . '/layout_footer.php'; ?>
