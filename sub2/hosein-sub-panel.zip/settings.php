<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
ensure_bootstrap_data();
require_login();

$settings = load_json('settings.json', ["subscription_token" => "", "title" => "Subscription Panel"]);
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_check();

  $settings['title'] = trim($_POST['title'] ?? 'Subscription Panel');
  $settings['subscription_token'] = trim($_POST['subscription_token'] ?? '');
  $settings['updated_at'] = now_iso();
  save_json('settings.json', $settings);

  // Change password (optional)
  $newpass = trim($_POST['new_password'] ?? '');
  if ($newpass !== '') {
    $users = load_json('users.json', []);
    $me = $_SESSION['user'];
    for ($i=0; $i<count($users); $i++) {
      if (isset($users[$i]['username']) && $users[$i]['username'] === $me) {
        $users[$i]['password_hash'] = password_hash($newpass, PASSWORD_DEFAULT);
        $users[$i]['updated_at'] = now_iso();
        break;
      }
    }
    save_json('users.json', $users);
  }

  $msg = 'ذخیره شد.';
}

include __DIR__ . '/layout_header.php';
?>
<div class="row justify-content-center">
  <div class="col-lg-7">
    <div class="card p-3">
      <h5 class="mb-3">تنظیمات</h5>
      <?php if ($msg): ?>
        <div class="alert alert-success"><?php echo h($msg); ?></div>
      <?php endif; ?>
      <form method="post">
        <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>">

        <div class="mb-3">
          <label class="form-label">عنوان پنل</label>
          <input class="form-control" name="title" value="<?php echo h($settings['title'] ?? ''); ?>">
        </div>

        <div class="mb-3">
          <label class="form-label">توکن سابسکریپشن (اختیاری)</label>
          <input class="form-control mono" name="subscription_token" value="<?php echo h($settings['subscription_token'] ?? ''); ?>" placeholder="اگر خالی باشد، لینک عمومی است">
          <div class="muted mt-1">اگر مقدار بدهی، کلاینت باید این را داشته باشد: <span class="mono">sub.php?token=...</span></div>
        </div>

        <hr style="border-color:#222">

        <div class="mb-3">
          <label class="form-label">تغییر رمز عبور (اختیاری)</label>
          <input class="form-control" type="password" name="new_password" placeholder="رمز جدید">
          <div class="muted mt-1">اگر خالی بگذاری تغییری نمی‌کند.</div>
        </div>

        <div class="d-flex gap-2">
          <button class="btn btn-light" type="submit">ذخیره</button>
          <a class="btn btn-outline-light" href="dashboard.php">بازگشت</a>
        </div>
      </form>
    </div>
  </div>
</div>
<?php include __DIR__ . '/layout_footer.php'; ?>
