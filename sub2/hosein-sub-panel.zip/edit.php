<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
ensure_bootstrap_data();
require_login();

$id = $_GET['id'] ?? '';
$servers = load_json('servers.json', []);
$server = null;
foreach ($servers as $s) {
  if (isset($s['id']) && $s['id'] === $id) { $server = $s; break; }
}
if (!$server) { header('Location: dashboard.php'); exit; }

include __DIR__ . '/layout_header.php';
?>
<div class="row justify-content-center">
  <div class="col-lg-7">
    <div class="card p-3">
      <h5 class="mb-3">ویرایش سرور</h5>
      <form method="post" action="update.php">
        <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>">
        <input type="hidden" name="id" value="<?php echo h($server['id']); ?>">
        <div class="mb-2">
          <label class="form-label">نام نمایشی</label>
          <input class="form-control" name="name" value="<?php echo h($server['name'] ?? ''); ?>" required>
        </div>
        <div class="mb-2">
          <label class="form-label">لینک کانفیگ</label>
          <textarea class="form-control mono" name="uri" rows="5" required><?php echo h($server['uri'] ?? ''); ?></textarea>
        </div>
        <div class="d-flex gap-2">
          <button class="btn btn-light" type="submit">ذخیره</button>
          <a class="btn btn-outline-light" href="dashboard.php">بازگشت</a>
        </div>
      </form>
    </div>
  </div>
</div>
<?php include __DIR__ . '/layout_footer.php'; ?>
