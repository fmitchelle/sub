<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
ensure_bootstrap_data();
require_login();

$id = $_GET['id'] ?? '';
$servers = load_json('servers.json', []);
$servers = array_values(array_filter($servers, function($s) use ($id) {
  return !isset($s['id']) || $s['id'] !== $id;
}));
save_json('servers.json', $servers);

$settings = load_json('settings.json', []);
$settings['updated_at'] = now_iso();
save_json('settings.json', $settings);

header('Location: dashboard.php');
exit;
