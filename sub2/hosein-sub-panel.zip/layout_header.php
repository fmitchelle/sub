<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
ensure_bootstrap_data();
$settings = load_json('settings.json', ["title" => "Subscription Panel"]);
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo h($settings['title'] ?? 'Subscription Panel'); ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <style>
    body{background:#0b0b0b;color:#f1f1f1}
    .card{background:#111;border:1px solid #222}
    .form-control,.form-select{background:#0f0f0f;border:1px solid #222;color:#f1f1f1}
    .form-control:focus,.form-select:focus{border-color:#444;box-shadow:none}
    .btn{border-radius:10px}
    .muted{color:#a0a0a0}
    a{color:#9ad0ff}
    .badge-soft{background:#1a1a1a;border:1px solid #2a2a2a;color:#ddd}
    .mono{font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;}
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark" style="background:#0e0e0e;border-bottom:1px solid #1f1f1f">
  <div class="container">
    <a class="navbar-brand" href="dashboard.php"><?php echo h($settings['title'] ?? 'Subscription Panel'); ?></a>
    <div class="ms-auto d-flex gap-2">
      <?php if (is_logged_in()): ?>
        <a class="btn btn-outline-light btn-sm" href="settings.php">تنظیمات</a>
        <a class="btn btn-outline-light btn-sm" href="logout.php">خروج</a>
      <?php endif; ?>
    </div>
  </div>
</nav>
<div class="container py-4">
