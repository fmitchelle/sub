<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
ensure_bootstrap_data();
require_login();

$settings = load_json('settings.json', ["subscription_token" => "", "title" => "Subscription Panel"]);
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_check();

  $settings['title'] = trim($_POST['title'] ?? 'Subscription Panel');
  $settings['subscription_token'] = trim($_POST['subscription_token'] ?? '');
  $settings['updated_at'] = now_iso();
  save_json('settings.json', $settings);

  $newpass = trim($_POST['new_password'] ?? '');
  if ($newpass !== '') {
    $users = load_json('users.json', []);
    $me = $_SESSION['user'];
    for ($i=0; $i<count($users); $i++) {
      if (isset($users[$i]['username']) && $users[$i]['username'] === $me) {
        $users[$i]['password_hash'] = password_hash($newpass, PASSWORD_DEFAULT);
        $users[$i]['updated_at'] = now_iso();
        break;
      }
    }
    save_json('users.json', $users);
  }

  $msg = 'ذخیره شد.';
}

$page_title = 'تنظیمات';
include __DIR__ . '/layout_header.php';
?>
<div class="row justify-content-center">
  <div class="col-lg-8">
    <div class="app-card p-3 p-lg-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
          <div class="fw-bold fs-5">تنظیمات</div>
          <div class="muted">توکن سابسکریپشن + تغییر رمز عبور</div>
        </div>
        <a class="btn btn-ghost" href="dashboard.php">بازگشت</a>
      </div>

      <?php if ($msg): ?>
        <div class="alert alert-success"><?php echo h($msg); ?></div>
      <?php endif; ?>

      <form method="post">
        <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>">

        <div class="mb-3">
          <label class="form-label">عنوان پنل</label>
          <input class="form-control" name="title" value="<?php echo h($settings['title'] ?? ''); ?>">
        </div>

        <div class="mb-3">
          <label class="form-label">توکن سابسکریپشن (اختیاری)</label>
          <input class="form-control mono" name="subscription_token" value="<?php echo h($settings['subscription_token'] ?? ''); ?>" placeholder="اگر خالی باشد، لینک عمومی است">
          <div class="muted small mt-2">
            اگر مقدار بدهی، لینک خروجی می‌شود: <span class="kbd mono">sub.php?token=...</span>
          </div>
        </div>

        <hr style="border-color:rgba(255,255,255,.08)">

        <div class="mb-3">
          <label class="form-label">تغییر رمز عبور (اختیاری)</label>
          <input class="form-control" type="password" name="new_password" placeholder="رمز جدید">
          <div class="muted small mt-2">اگر خالی بگذاری تغییری نمی‌کند.</div>
        </div>

        <button class="btn btn-accent fw-bold w-100" type="submit">ذخیره</button>
      </form>
    </div>
  </div>
</div>
<?php include __DIR__ . '/layout_footer.php'; ?>
