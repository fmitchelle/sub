
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // tiny helper: copy
  function copyText(id){
    const el = document.getElementById(id);
    if(!el) return;
    const v = el.value || el.textContent || '';
    navigator.clipboard && navigator.clipboard.writeText(v);
  }
</script>
</body>
</html>
