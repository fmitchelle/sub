<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
ensure_bootstrap_data();
require_login();
csrf_check();

$default_name = trim($_POST['default_name'] ?? '');
$uris_raw = (string)($_POST['uris'] ?? '');
$lines = preg_split('/\R/u', $uris_raw);

$servers = load_json('servers.json', []);
$added = 0;

foreach ($lines as $ln) {
  $uri = trim($ln);
  if ($uri === '') continue;
  $id = bin2hex(random_bytes(8));
  $name = $default_name !== '' ? $default_name : 'Server ' . ($added + 1);

  $servers[] = [
    "id" => $id,
    "name" => $name,
    "uri" => $uri,
    "created_at" => now_iso()
  ];
  $added++;
}

save_json('servers.json', $servers);

$settings = load_json('settings.json', []);
$settings['updated_at'] = now_iso();
save_json('settings.json', $settings);

header('Location: dashboard.php');
exit;
