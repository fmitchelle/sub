<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
ensure_bootstrap_data();
require_login();

$servers  = load_json('servers.json', []);
$settings = load_json('settings.json', ["subscription_token" => "", "title" => "Subscription Panel"]);

$scheme = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
$base   = $scheme . '://' . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['REQUEST_URI']), '/\\');
$subUrl = $base . '/sub.php';
$rawUrl = $subUrl . '?raw=1';

$token = trim($settings['subscription_token'] ?? '');
if ($token !== '') {
  $subUrl .= '?token=' . urlencode($token);
  $rawUrl  = $subUrl . '&raw=1';
}

$total = count($servers);
$lastUpdate = $settings['updated_at'] ?? '-';
$page_title = 'داشبورد';

include __DIR__ . '/layout_header.php';
?>
<div class="row g-3 g-lg-4">
  <div class="col-lg-3">
    <div class="sidebar">
      <div class="d-flex align-items-center gap-3 mb-3">
        <div class="dot"></div>
        <div>
          <div class="fw-bold"><?php echo h($settings['title'] ?? 'Subscription Panel'); ?></div>
          <div class="muted small">مدیریت حرفه‌ای Subscription</div>
        </div>
      </div>

      <a class="navpill active" href="dashboard.php">
        <span class="badge-soft">🏠</span>
        <div>
          <div class="fw-semibold">داشبورد</div>
          <div class="muted small">لیست و مدیریت سرورها</div>
        </div>
      </a>

      <a class="navpill" href="settings.php">
        <span class="badge-soft">⚙️</span>
        <div>
          <div class="fw-semibold">تنظیمات</div>
          <div class="muted small">توکن + تغییر رمز</div>
        </div>
      </a>

      <div class="app-card p-3 mt-3">
        <div class="d-flex justify-content-between align-items-center">
          <div class="muted small">وضعیت</div>
          <span class="badge-soft">Live</span>
        </div>
        <div class="mt-2 fw-bold fs-4"><?php echo $total; ?></div>
        <div class="muted small">سرور ثبت شده</div>
        <div class="muted small mt-2">آخرین بروزرسانی</div>
        <div class="small mono"><?php echo h($lastUpdate); ?></div>
      </div>

      <div class="muted small mt-3">
        نکته: خروجی این پنل به صورت <span class="kbd">Base64</span> از لینک‌هاست (V2Ray/Xray).
      </div>
    </div>
  </div>

  <div class="col-lg-9">
    <!-- Topbar -->
    <div class="topbar mb-3">
      <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-2">
        <div>
          <div class="fw-bold fs-5">داشبورد</div>
          <div class="muted">لینک Subscription را بده به کاربر؛ هر تغییر اینجا، با Update در کلاینت اعمال می‌شود.</div>
        </div>
        <div class="d-flex gap-2">
          <a class="btn btn-ghost" href="settings.php">تنظیمات</a>
          <a class="btn btn-ghost" href="logout.php">خروج</a>
        </div>
      </div>
    </div>

    <div class="row g-3">
      <div class="col-md-7">
        <div class="app-card p-3 p-lg-4 h-100">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <div class="fw-bold">لینک Subscription</div>
            <span class="badge-soft">V2rayNG / V2Box / Hiddify</span>
          </div>
          <div class="muted mb-2">این URL را وارد کن و Refresh/Update بزن.</div>
          <div class="input-group">
            <input class="form-control mono" id="subUrl" value="<?php echo h($subUrl); ?>" readonly>
            <button class="btn btn-accent" type="button" onclick="copyText('subUrl')">کپی</button>
          </div>
          <div class="mt-3 d-flex flex-column flex-sm-row gap-2">
            <a class="btn btn-ghost" href="<?php echo h($subUrl); ?>" target="_blank" rel="noopener">باز کردن خروجی</a>
            <button class="btn btn-ghost" type="button" onclick="copyText('rawUrl')">کپی لینک Raw</button>
            <input class="form-control mono d-none" id="rawUrl" value="<?php echo h($rawUrl); ?>" readonly>
          </div>
          <div class="muted small mt-3">
            تست خام: <span class="mono"><?php echo h($rawUrl); ?></span>
          </div>
        </div>
      </div>

      <div class="col-md-5">
        <div class="app-card p-3 p-lg-4 h-100">
          <div class="fw-bold mb-2">افزودن سریع</div>
          <div class="muted mb-3">یک لینک اضافه کن یا چند لینک را یکجا Paste کن (هر خط = یک سرور).</div>
          <form method="post" action="bulk_save.php">
            <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>">
            <div class="mb-2">
              <label class="form-label">نام پیش‌فرض (اختیاری)</label>
              <input class="form-control" name="default_name" placeholder="اگر خالی باشد، از خود لینک استفاده می‌شود">
            </div>
            <div class="mb-3">
              <label class="form-label">لینک‌ها</label>
              <textarea class="form-control mono" name="uris" rows="5" placeholder="vless://...
vmess://...
trojan://..." required></textarea>
            </div>
            <button class="btn btn-accent w-100 fw-bold" type="submit">ثبت</button>
          </form>
        </div>
      </div>
    </div>

    <div class="app-card p-3 p-lg-4 mt-3">
      <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-2">
        <div>
          <div class="fw-bold">لیست سرورها</div>
          <div class="muted">مدیریت، ویرایش و حذف. (نمایش لینک کوتاه‌شده برای خوانایی)</div>
        </div>
        <div class="d-flex gap-2">
          <input class="form-control" id="search" placeholder="جستجو..." oninput="filterRows()">
          <span class="badge-soft align-self-center"><?php echo $total; ?> مورد</span>
        </div>
      </div>

      <div class="table-responsive mt-3">
        <table class="table table-dark table-sm align-middle mb-0" id="srvTable">
          <thead>
            <tr>
              <th style="width:220px">نام</th>
              <th>لینک</th>
              <th class="text-end" style="width:190px">عملیات</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!$total): ?>
              <tr><td colspan="3" class="muted">فعلاً چیزی ثبت نشده.</td></tr>
            <?php else: ?>
              <?php foreach ($servers as $s): ?>
                <tr>
                  <td class="fw-semibold"><?php echo h($s['name'] ?? '-'); ?></td>
                  <td class="mono" title="<?php echo h($s['uri'] ?? ''); ?>" style="max-width:520px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                    <?php echo h($s['uri'] ?? ''); ?>
                  </td>
                  <td class="text-end">
                    <a class="btn btn-ghost btn-sm" href="edit.php?id=<?php echo urlencode($s['id']); ?>">ویرایش</a>
                    <a class="btn btn-outline-danger btn-sm" href="delete.php?id=<?php echo urlencode($s['id']); ?>" onclick="return confirm('حذف شود؟')">حذف</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</div>

<script>
function filterRows(){
  const q = (document.getElementById('search').value || '').toLowerCase().trim();
  const rows = document.querySelectorAll('#srvTable tbody tr');
  rows.forEach(r => {
    const t = r.textContent.toLowerCase();
    r.style.display = t.includes(q) ? '' : 'none';
  });
}
</script>
<?php include __DIR__ . '/layout_footer.php'; ?>
